# MUSTELLO image sources

The portfolio uses five different, locally stored WebP assets. Each file was downloaded from Wikimedia Commons and resized or recompressed locally for the website. Portfolio cards identify the work as **Sample concept / illustrative** and do not claim that any image depicts a completed client project, a specific plugin, or a specific server.

## Java Plugin Systems

- Local file: `src/assets/minecraft/java-plugins.webp`
- Source page: https://commons.wikimedia.org/wiki/File:Minecraft_Beta_1.8.1_Gameplay_Screenshot.png
- Original image: https://upload.wikimedia.org/wikipedia/commons/5/53/Minecraft_Beta_1.8.1_Gameplay_Screenshot.png
- License: Creative Commons Attribution 3.0 Unported (CC BY 3.0)
- Credit: Xbox México, sourced from the Xbox Masterclass video. Provide appropriate credit, a link to the license, and indicate changes.

## Bedrock Behavior Pack Lab

- Local file: `src/assets/minecraft/bedrock-addons.webp`
- Source page: https://commons.wikimedia.org/wiki/File:Minecraft_Bedrock_Inventory_in_Creative_Mode.png
- Original image: https://upload.wikimedia.org/wikipedia/commons/f/f3/Minecraft_Bedrock_Inventory_in_Creative_Mode.png
- License: Creative Commons Attribution 3.0 Unported (CC BY 3.0)
- Credit: Xbox México, sourced from the Xbox Masterclass video. Provide appropriate credit, a link to the license, and indicate changes.

## Custom Mobs & AI

- Local file: `src/assets/minecraft/custom-mobs.webp`
- Source page: https://commons.wikimedia.org/wiki/File:Minecraft_Creeper_(Crop).png
- Original image: https://upload.wikimedia.org/wikipedia/commons/a/a9/Minecraft_Creeper_%28Crop%29.png
- License: Creative Commons Attribution 3.0 Unported (CC BY 3.0)
- Credit: Xbox México, sourced from the Xbox Masterclass video. Provide appropriate credit, a link to the license, and indicate changes.

## Geyser + Floodgate Bridge

- Local file: `src/assets/minecraft/geyser-crossplay.webp`
- Source page: https://commons.wikimedia.org/wiki/File:Creatief_met_Minecraft.jpg
- Original image: https://upload.wikimedia.org/wikipedia/commons/f/f7/Creatief_met_Minecraft.jpg
- License: Creative Commons CC0 1.0 Universal Public Domain Dedication.
- Credit: Courtesy credit recommended for bruno (brunobib), with a link to the source page. No attribution is legally required under CC0.

## Server Development Stack

- Local file: `src/assets/minecraft/server-development.webp`
- Source page: https://commons.wikimedia.org/wiki/File:Screenshot_from_the_Minecraft_Nether.png
- Original image: https://upload.wikimedia.org/wikipedia/commons/c/cd/Screenshot_from_the_Minecraft_Nether.png
- License: Creative Commons Attribution 3.0 Unported (CC BY 3.0)
- Credit: Xbox México, sourced from the Xbox Masterclass video. Provide appropriate credit, a link to the license, and indicate changes.

Minecraft and related marks remain subject to their owners’ trademark and other legal rights. This record documents the file licenses shown on the cited Wikimedia Commons pages; anyone publishing or redistributing the site should review the source pages and applicable local law before launch.
