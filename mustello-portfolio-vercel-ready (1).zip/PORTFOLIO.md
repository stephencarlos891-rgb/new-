# Portfolio handoff

The editable portfolio facts live in `src/data/portfolio.ts`. The five project cards are explicitly labeled sample concepts and use different optimized local WebP assets under `src/assets/minecraft/`. Image source pages, original URLs, licenses, and attribution notes are recorded in `IMAGE_SOURCES.md`.

Add a real email, GitHub URL, LinkedIn URL, genuine dated experience, and actual client work only when those details are available. Empty URLs remain unlinked. The Fiverr contact button remains the existing `https://www.fiverr.com/s/xrkLmjX` path.

The site keeps the existing TanStack routes and visual system. `public/manus-routes.json` declares the full route set for the managed preview. Run `bun install --frozen-lockfile`, `bun run lint`, `bun run test`, and `bun run build` before deploying to Vercel. In this sandbox Bun was unavailable, so the same checks were run with pnpm; lint has no errors, all 10 tests pass, and the Vercel-targeted build succeeds.

Validation completed on the managed preview: `/`, `/about`, `/skills`, `/projects`, `/experience`, `/services`, and `/contact` return HTTP 200; `GET /manus-routes.json` returns the seven-route JSON manifest; all five local WebP assets return HTTP 200 with `image/webp`; and desktop plus 375px mobile screenshots show the five distinct images and responsive stacked cards. The Fiverr path remains unchanged. The external Fiverr edge returned HTTP 403 to automated curl, while all five Wikimedia Commons source pages returned HTTP 200.

The supplied archive has no `.git` directory or GitHub remote, so no GitHub update was possible. `vite.config.ts` pins Nitro to the Vercel preset, `vercel.json` declares the Bun install/build commands, and `app.config.ts` contains the durable favicon logo URL required by the managed project.
