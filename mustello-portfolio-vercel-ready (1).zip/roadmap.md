# MUSTELLO portfolio
- [x] Build the light/navy design and original voxel artwork.
- [x] Add portfolio pages, project filtering, and honest content placeholders.
- [x] Add contact drafting, metadata, and editing/deployment notes.
- [x] Verify navigation, filtering, contact, and mobile layout.