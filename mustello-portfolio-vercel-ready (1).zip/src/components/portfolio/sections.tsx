import { useState } from "react";
import { Link } from "@tanstack/react-router";
import {
  ArrowRight,
  ArrowUpRight,
  Blocks,
  Box,
  Braces,
  Check,
  Code2,
  Download,
  ExternalLink,
  FileCode2,
  Gauge,
  Github,
  Layers,
  Network,
  Puzzle,
  ShieldCheck,
  Sparkles,
  Terminal,
  WandSparkles,
  Zap,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { categories, filterProjects, portfolio, type ProjectCategory } from "@/data/portfolio";
import heroImage from "@/assets/minecraft/java-plugins.webp";

export function SectionHeading({
  kicker,
  title,
  description,
}: {
  kicker: string;
  title: string;
  description?: string;
}) {
  return (
    <div>
      <p className="eyebrow section-kicker">{kicker}</p>
      <h2 className="section-title">{title}</h2>
      {description && <p className="section-copy mt-3 max-w-xl">{description}</p>}
    </div>
  );
}

export function PageHeading({
  kicker,
  title,
  description,
}: {
  kicker: string;
  title: string;
  description: string;
}) {
  return (
    <div className="page-wrap page-heading">
      <p className="eyebrow section-kicker">{kicker}</p>
      <h1>{title}</h1>
      <p className="section-copy max-w-2xl">{description}</p>
    </div>
  );
}

export function AboutSection({ compact = false }: { compact?: boolean }) {
  return (
    <section className="page-wrap section section-rule">
      <div className="grid gap-10 md:grid-cols-[1fr_1.2fr] md:gap-20">
        <div>
          <SectionHeading
            kicker="Behind the code"
            title="A developer. A builder. A Minecraft person."
          />
          <p className="section-copy mt-5">{portfolio.bio}</p>
          {compact && (
            <Link
              to="/about"
              className="mt-5 inline-flex items-center gap-2 text-xs font-semibold text-primary"
            >
              A little more about me <ArrowUpRight size={15} />
            </Link>
          )}
        </div>
        <div className="grid content-center gap-6">
          {[
            {
              icon: Code2,
              title: "Built for real gameplay",
              text: "Custom mechanics, smarter entities, and systems that feel native to your world.",
            },
            {
              icon: Network,
              title: "Connecting both editions",
              text: "Java and Bedrock compatibility with GeyserMC, Floodgate, and careful multiplayer integration.",
            },
            {
              icon: Gauge,
              title: "Details make the difference",
              text: "A focus on clean implementation, thoughtful debugging, and server performance.",
            },
          ].map(({ icon: Icon, title, text }) => (
            <div key={title} className="flex gap-4">
              <span className="icon-tile shrink-0">
                <Icon size={19} />
              </span>
              <div>
                <h3 className="text-sm font-semibold">{title}</h3>
                <p className="section-copy mt-1">{text}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
      {!compact && (
        <div className="mt-12 grid gap-8 border-t border-border pt-8 md:grid-cols-3">
          {[
            {
              title: "Background",
              text: "Professional background, education, and qualifications have not been provided yet.",
            },
            {
              title: "Interests",
              text: "Minecraft gameplay systems, custom mobs, AI behaviors, and cross-edition compatibility.",
            },
            {
              title: "Career goals",
              text: "Add your personal career goals and the kind of team or role you’re looking for.",
            },
          ].map((item) => (
            <div key={item.title}>
              <h3 className="mb-2 text-base font-semibold">{item.title}</h3>
              <p className="section-copy">{item.text}</p>
              {item.title !== "Interests" && (
                <span className="chip mt-3 inline-block">Details to be added</span>
              )}
            </div>
          ))}
        </div>
      )}
    </section>
  );
}

const skillGroups = [
  {
    icon: Puzzle,
    title: "Plugins & server systems",
    text: "Purpose-built mechanics for Java servers.",
    tags: ["Java", "Paper & Spigot", "Combat mechanics", "NPC shops", "API integration"],
    tone: "",
  },
  {
    icon: Blocks,
    title: "Bedrock & custom content",
    text: "New possibilities, one block at a time.",
    tags: ["JavaScript", "Bedrock addons", "Custom mobs", "Entity components", "Resource packs"],
    tone: "cyan",
  },
  {
    icon: Network,
    title: "Crossplay & performance",
    text: "Connected players. Smooth experiences.",
    tags: ["GeyserMC", "Floodgate", "Server optimization", "Multiplayer", "Advanced debugging"],
    tone: "green",
  },
];

export function SkillsSection({ compact = false }: { compact?: boolean }) {
  return (
    <section className="page-wrap section section-rule">
      <div className="flex flex-wrap items-end justify-between gap-6">
        <SectionHeading kicker="The toolkit" title="Technical skills. Creative possibilities." />
        {compact && (
          <Link to="/skills" className="flex items-center gap-1 text-xs text-muted-foreground">
            Explore my skills <ArrowUpRight size={15} />
          </Link>
        )}
      </div>
      <div className="mt-8 grid gap-5 md:grid-cols-3">
        {skillGroups.map(({ icon: Icon, title, text, tags, tone }) => (
          <article className="skill-card" key={title}>
            <div className={`icon-tile ${tone}`}>
              <Icon size={20} />
            </div>
            <h3>{title}</h3>
            <p className="section-copy mt-2 text-xs">{text}</p>
            <div className="mt-5 flex flex-wrap gap-1.5">
              {tags.map((tag) => (
                <span key={tag} className="chip">
                  {tag}
                </span>
              ))}
            </div>
          </article>
        ))}
      </div>
      {!compact && (
        <div className="mt-8 flex flex-wrap gap-3">
          {[
            "AI behaviors",
            "Gameplay systems",
            "Bug fixes",
            "Downloadable files",
            "Premium modding",
            "JavaScript scripting",
          ].map((item) => (
            <span className="flex items-center gap-2 text-xs text-muted-foreground" key={item}>
              <Check size={14} className="text-success" />
              {item}
            </span>
          ))}
        </div>
      )}
    </section>
  );
}

export function ProjectsSection({ compact = false }: { compact?: boolean }) {
  const [category, setCategory] = useState<ProjectCategory>("All projects");
  const filtered = filterProjects(category);
  return (
    <section className="page-wrap section section-rule">
      <div className="flex flex-wrap items-end justify-between gap-6">
        <SectionHeading kicker="Selected work" title="From an idea to a playable world." />
        {compact && (
          <Link to="/projects" className="flex items-center gap-1 text-xs text-muted-foreground">
            All projects <ArrowUpRight size={15} />
          </Link>
        )}
      </div>
      <div className="mt-6 flex flex-wrap gap-1" role="group" aria-label="Filter projects">
        {categories.map((item) => (
          <Button
            key={item}
            variant="filter"
            size="sm"
            data-active={category === item}
            aria-pressed={category === item}
            onClick={() => setCategory(item)}
          >
            {item}
          </Button>
        ))}
      </div>
      <p className="mb-5 mt-4 text-[10px] text-muted-foreground">
        Sample concepts for demonstration · Not completed client work. Image sources and licenses
        are documented in the project archive.
      </p>
      <div className="grid gap-5 md:grid-cols-3" aria-live="polite">
        {filtered.map((project, index) => (
          <article key={project.id} className="project-card">
            <div className={`project-art variant-${(index % 3) + 1}`}>
              <img src={project.image} width={1536} height={1024} alt={project.alt} />
              <span className="project-label">
                SAMPLE CONCEPT / {project.category.toUpperCase()}
              </span>
            </div>
            <div className="p-5">
              <div className="flex items-start justify-between gap-3">
                <h3 className="text-lg font-semibold">{project.title}</h3>
                <span className="chip shrink-0">Illustrative</span>
              </div>
              <p className="section-copy mt-2 text-xs">{project.description}</p>
              <div className="mt-4 flex flex-wrap gap-1.5">
                {project.technologies.map((tag) => (
                  <span className="chip" key={tag}>
                    {tag}
                  </span>
                ))}
              </div>
              <div className="mt-5 flex flex-wrap gap-3 border-t border-border pt-4">
                <a
                  href={project.sourceUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="flex items-center gap-1 text-xs"
                >
                  <ExternalLink size={14} />
                  Image source
                </a>
                {project.github && (
                  <a
                    href={project.github}
                    target="_blank"
                    rel="noreferrer"
                    className="flex items-center gap-1 text-xs"
                  >
                    <Github size={14} />
                    Source
                  </a>
                )}
                {project.demo && (
                  <a
                    href={project.demo}
                    target="_blank"
                    rel="noreferrer"
                    className="flex items-center gap-1 text-xs"
                  >
                    <ExternalLink size={14} />
                    Live demo
                  </a>
                )}
                {project.download && (
                  <a href={project.download} download className="flex items-center gap-1 text-xs">
                    <Download size={14} />
                    Download
                  </a>
                )}
                <span className="w-full text-[10px] text-muted-foreground">
                  {project.sourceCredit} · Optimized local WebP
                </span>
              </div>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}

export function ExperienceSection() {
  return (
    <section className="page-wrap section section-rule">
      <SectionHeading
        kicker="The journey"
        title="Experience & milestones"
        description="A place for the real work, learning, and accomplishments behind the code."
      />
      <div className="mt-8 max-w-3xl border-l border-border pl-7">
        <div className="relative">
          <span className="absolute -left-8 top-1 h-2 w-2 rounded-full bg-primary" />
          <span className="chip">Details to be added</span>
          <h3 className="mb-3 mt-4 text-xl font-semibold">Your experience belongs here.</h3>
          <p className="section-copy">
            No roles, dates, employers, or achievements have been provided. Add your genuine
            experience, including independent development, open-source contributions, education, or
            server projects.
          </p>
        </div>
      </div>
    </section>
  );
}

export function ServicesSection() {
  const services = [
    {
      icon: FileCode2,
      title: "Custom plugin development",
      description:
        "Paper and Spigot plugins, combat mechanics, NPC shops, and custom gameplay systems.",
    },
    {
      icon: WandSparkles,
      title: "Bedrock addon development",
      description:
        "Custom mobs, entity components, JavaScript scripting, AI behaviors, and resource packs.",
    },
    {
      icon: Network,
      title: "Crossplay configuration",
      description:
        "GeyserMC and Floodgate setup, Java/Bedrock integration, and multiplayer compatibility.",
    },
    {
      icon: Gauge,
      title: "Optimization & debugging",
      description: "Server optimization, bug fixes, advanced debugging, and API integration.",
    },
  ];
  return (
    <section className="page-wrap section section-rule">
      <SectionHeading
        kicker="What I can build"
        title="Your world. Custom-built."
        description="Development specialties for Minecraft servers and experiences."
      />
      <div className="mt-8 grid gap-5 sm:grid-cols-2">
        {services.map(({ icon: Icon, title, description }) => (
          <article key={title} className="skill-card flex gap-5">
            <span className="icon-tile shrink-0">
              <Icon size={20} />
            </span>
            <div>
              <h3 className="!mt-0">{title}</h3>
              <p className="section-copy mt-2">{description}</p>
              <Link
                to="/contact"
                className="mt-4 inline-flex items-center gap-1 text-xs font-medium text-primary"
              >
                Discuss a project <ArrowUpRight size={14} />
              </Link>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}

export function ContactBanner() {
  return (
    <section className="page-wrap section">
      <div className="cta-band flex flex-col justify-between gap-8 sm:flex-row sm:items-center">
        <div>
          <p className="eyebrow mb-3 flex items-center gap-2 text-cyan">
            <Sparkles size={13} /> Let’s build something
          </p>
          <h2 className="text-3xl font-semibold">Have a world in mind?</h2>
          <p className="mt-3 text-xs">Let’s turn your next idea into something players love.</p>
        </div>
        <Button asChild variant="hero" size="lg">
          <Link to="/contact">
            Let’s talk <ArrowUpRight />
          </Link>
        </Button>
      </div>
    </section>
  );
}

export function TechStrip() {
  return (
    <div className="tech-strip">
      <div className="page-wrap flex flex-wrap items-center justify-between gap-x-6 gap-y-4">
        <span className="eyebrow text-[9px] text-muted-foreground">Built around the ecosystem</span>
        {[
          { icon: Box, name: "Minecraft" },
          { icon: Code2, name: "Java" },
          { icon: Braces, name: "JavaScript" },
          { icon: Layers, name: "Paper & Spigot" },
          { icon: Network, name: "GeyserMC" },
        ].map(({ icon: Icon, name }) => (
          <span key={name} className="tech-item">
            <Icon size={17} strokeWidth={1.5} />
            {name}
          </span>
        ))}
      </div>
    </div>
  );
}

export function Hero() {
  return (
    <section className="hero">
      <img
        src={heroImage}
        className="hero-art"
        alt="Minecraft landscape used as illustrative portfolio artwork"
        width={1494}
        height={791}
        fetchPriority="high"
      />
      <div className="hero-shade" />
      <div className="page-wrap hero-content">
        <p className="eyebrow flex items-center gap-2 text-cyan">
          <span className="h-1.5 w-1.5 rounded-full bg-cyan" /> Minecraft developer & creative
          problem solver
        </p>
        <h1>
          MUSTELLO<span className="text-cyan">.</span>
        </h1>
        <p className="hero-subtitle">
          Building better worlds,
          <br />
          one line of code at a time.
        </p>
        <p className="hero-copy">
          Custom plugins. Smarter mobs. Seamless crossplay.
          <br />I turn ambitious Minecraft ideas into thoughtful,
          <br className="hidden sm:block" /> well-crafted gameplay experiences.
        </p>
        <div className="mb-7 mt-7 flex flex-wrap gap-3">
          <Button asChild variant="hero" size="lg">
            <Link to="/projects">
              View projects <ArrowUpRight />
            </Link>
          </Button>
          <Button asChild variant="glass" size="lg">
            <a href="https://www.fiverr.com/s/xrkLmjX">
              Contact me <ArrowRight />
            </a>
          </Button>
        </div>
        <div className="flex flex-wrap gap-2">
          <span className="hero-tag">
            <Terminal size={12} className="text-cyan" /> Java & Bedrock
          </span>
          <span className="hero-tag">
            <Zap size={12} className="text-cyan" /> Custom gameplay
          </span>
          <span className="hero-tag">
            <ShieldCheck size={12} className="text-cyan" /> Crossplay-ready
          </span>
        </div>
      </div>
      <span className="hero-note">CRAFTED IN CODE. INSPIRED BY BLOCKS.</span>
    </section>
  );
}
