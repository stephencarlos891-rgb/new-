import { useState } from "react";
import { Link } from "@tanstack/react-router";
import { ArrowUpRight, Box, Github, Linkedin, Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { portfolio } from "@/data/portfolio";

const navigation = [
  { label: "Home", to: "/" },
  { label: "About", to: "/about" },
  { label: "Skills", to: "/skills" },
  { label: "Projects", to: "/projects" },
  { label: "Experience", to: "/experience" },
  { label: "Services", to: "/services" },
] as const;

export function SiteHeader() {
  const [open, setOpen] = useState(false);
  return (
    <header className="site-header sticky top-0 z-50">
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:absolute focus:bg-background focus:p-3"
      >
        Skip to content
      </a>
      <div className="page-wrap flex h-full items-center justify-between gap-6">
        <Link to="/" aria-label="MUSTELLO home" className="flex items-center gap-2.5">
          <span className="brand-icon">
            <Box size={21} strokeWidth={1.7} />
          </span>
          <span className="wordmark">
            MUSTELLO<span className="text-primary">.</span>
          </span>
        </Link>
        <nav aria-label="Main navigation" className="hidden items-center gap-6 lg:flex">
          {navigation.map(({ label, to }) => (
            <Link key={to} to={to} className="nav-link" activeOptions={{ exact: true }}>
              {label}
            </Link>
          ))}
        </nav>
        <div className="flex items-center gap-2">
          <Button asChild className="hidden sm:inline-flex">
            <Link to="/contact">
              Let’s talk <ArrowUpRight />
            </Link>
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="lg:hidden"
            aria-label={open ? "Close navigation" : "Open navigation"}
            aria-expanded={open}
            onClick={() => setOpen(!open)}
          >
            {open ? <X /> : <Menu />}
          </Button>
        </div>
      </div>
      {open && (
        <nav
          aria-label="Mobile navigation"
          className="absolute top-full w-full border-b border-border bg-background p-5 shadow-sm lg:hidden"
        >
          <div className="grid grid-cols-2 gap-5">
            {navigation.map(({ label, to }) => (
              <Link key={to} to={to} onClick={() => setOpen(false)} className="nav-link">
                {label}
              </Link>
            ))}
            <Link to="/contact" onClick={() => setOpen(false)} className="nav-link">
              Contact
            </Link>
          </div>
        </nav>
      )}
    </header>
  );
}

export function SiteFooter() {
  return (
    <footer className="site-footer">
      <div className="page-wrap flex flex-col justify-between gap-6 sm:flex-row sm:items-center">
        <div>
          <Link to="/" className="font-display text-lg font-semibold">
            MUSTELLO<span className="text-primary">.</span>
          </Link>
          <p className="mt-1 text-[10px] text-muted-foreground">Thoughtful code. Better worlds.</p>
        </div>
        <p className="text-[10px] text-muted-foreground">© 2026 MUSTELLO. Built with intent.</p>
        <div className="flex items-center gap-4">
          {portfolio.github && (
            <a
              href={portfolio.github}
              target="_blank"
              rel="noreferrer"
              aria-label="MUSTELLO on GitHub"
            >
              <Github size={17} />
            </a>
          )}
          {portfolio.linkedin && (
            <a
              href={portfolio.linkedin}
              target="_blank"
              rel="noreferrer"
              aria-label="MUSTELLO on LinkedIn"
            >
              <Linkedin size={17} />
            </a>
          )}
          <Link to="/contact" className="flex items-center gap-1 text-xs">
            Get in touch <ArrowUpRight size={14} />
          </Link>
        </div>
      </div>
    </footer>
  );
}
