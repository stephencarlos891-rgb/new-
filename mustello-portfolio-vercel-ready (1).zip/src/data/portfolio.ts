import javaPluginsImage from "@/assets/minecraft/java-plugins.webp";
import bedrockAddonsImage from "@/assets/minecraft/bedrock-addons.webp";
import customMobsImage from "@/assets/minecraft/custom-mobs.webp";
import geyserCrossplayImage from "@/assets/minecraft/geyser-crossplay.webp";
import serverDevelopmentImage from "@/assets/minecraft/server-development.webp";

export const portfolio = {
  name: "MUSTELLO",
  email: "", // Add your real email to enable the email contact option.
  github: "",
  linkedin: "",
  bio: "I’m MUSTELLO, a developer focused on the systems that bring Minecraft worlds to life. My technical focus spans Java server plugins, Bedrock addons, and the bridge between them.",
};

export const categories = [
  "All projects",
  "Java plugins",
  "Bedrock addons",
  "Custom mobs & AI",
  "Crossplay",
  "Server development",
] as const;
export type ProjectCategory = (typeof categories)[number];

export const projects = [
  {
    id: "java",
    title: "Java Plugin Systems",
    category: "Java plugins",
    description:
      "A sample concept for a Paper or Spigot plugin: modular gameplay systems, commands, permissions, and server-side polish designed around real player loops.",
    technologies: ["Java", "Paper", "Spigot"],
    github: "",
    demo: "",
    download: "",
    image: javaPluginsImage,
    alt: "Minecraft landscape screenshot used as an illustrative sample concept for Java plugin systems",
    sourceUrl:
      "https://commons.wikimedia.org/wiki/File:Minecraft_Beta_1.8.1_Gameplay_Screenshot.png",
    sourceCredit: "Xbox México · CC BY 3.0",
  },
  {
    id: "bedrock",
    title: "Bedrock Behavior Pack Lab",
    category: "Bedrock addons",
    description:
      "A sample concept for Bedrock addons and scripting: custom components, event-driven behaviors, and resource-pack coordination for a cohesive player experience.",
    technologies: ["JavaScript", "Bedrock API", "JSON"],
    github: "",
    demo: "",
    download: "",
    image: bedrockAddonsImage,
    alt: "Minecraft Bedrock creative inventory screenshot used as an illustrative sample concept for addon scripting",
    sourceUrl:
      "https://commons.wikimedia.org/wiki/File:Minecraft_Bedrock_Inventory_in_Creative_Mode.png",
    sourceCredit: "Xbox México · CC BY 3.0",
  },
  {
    id: "mobs",
    title: "Custom Mobs & AI",
    category: "Custom mobs & AI",
    description:
      "A sample concept for custom entities: readable combat states, target selection, navigation, and AI behaviors that make a mob feel intentional instead of random.",
    technologies: ["Java", "Entity AI", "Behavior trees"],
    github: "",
    demo: "",
    download: "",
    image: customMobsImage,
    alt: "Minecraft creeper screenshot used as an illustrative sample concept for custom mobs and AI behaviors",
    sourceUrl: "https://commons.wikimedia.org/wiki/File:Minecraft_Creeper_(Crop).png",
    sourceCredit: "Xbox México · CC BY 3.0",
  },
  {
    id: "crossplay",
    title: "Geyser + Floodgate Bridge",
    category: "Crossplay",
    description:
      "A sample concept for a Java and Bedrock bridge: identity flow, permissions, gameplay parity, and a smoother multiplayer experience across editions.",
    technologies: ["GeyserMC", "Floodgate", "Paper"],
    github: "",
    demo: "",
    download: "",
    image: geyserCrossplayImage,
    alt: "Person playing Minecraft used as an illustrative sample concept for GeyserMC and Floodgate crossplay",
    sourceUrl: "https://commons.wikimedia.org/wiki/File:Creatief_met_Minecraft.jpg",
    sourceCredit: "bruno · CC0 1.0",
  },
  {
    id: "server",
    title: "Server Development Stack",
    category: "Server development",
    description:
      "A sample concept for a production-minded Minecraft server: onboarding, gameplay services, performance budgets, and systems that stay dependable as the world grows.",
    technologies: ["Paper", "Performance", "Multiplayer"],
    github: "",
    demo: "",
    download: "",
    image: serverDevelopmentImage,
    alt: "Minecraft Nether screenshot used as an illustrative sample concept for server development",
    sourceUrl: "https://commons.wikimedia.org/wiki/File:Screenshot_from_the_Minecraft_Nether.png",
    sourceCredit: "Xbox México · CC BY 3.0",
  },
] as const;

export function filterProjects(category: ProjectCategory) {
  return category === "All projects"
    ? projects
    : projects.filter((project) => project.category === category);
}

export function createMessageDraft(name: string, email: string, message: string) {
  return `To: ${portfolio.email || "[MUSTELLO’s email — not yet provided]"}\nSubject: Portfolio inquiry from ${name}\nFrom: ${name} <${email}>\n\n${message}`;
}

export function pageMeta(title: string, description: string) {
  return {
    meta: [
      { title: `${title} — MUSTELLO` },
      { name: "description", content: description },
      { property: "og:title", content: `${title} — MUSTELLO` },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  };
}
