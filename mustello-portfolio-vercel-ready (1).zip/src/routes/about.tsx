import { createFileRoute } from "@tanstack/react-router";
import { AboutSection, ContactBanner, PageHeading } from "@/components/portfolio/sections";
import { pageMeta } from "@/data/portfolio";
export const Route = createFileRoute("/about")({
  head: () =>
    pageMeta(
      "About",
      "Meet MUSTELLO, a developer focused on Minecraft gameplay systems, Java plugins, Bedrock addons, and crossplay.",
    ),
  component: About,
});
function About() {
  return (
    <main id="main">
      <PageHeading
        kicker="The person behind the plugins"
        title="Hello, I’m MUSTELLO."
        description="A Minecraft-focused developer with an interest in the mechanics, connections, and details that make a world worth playing."
      />
      <AboutSection />
      <ContactBanner />
    </main>
  );
}
