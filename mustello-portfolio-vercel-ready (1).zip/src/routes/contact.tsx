import { useState, type FormEvent } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { ArrowUpRight, Download, Github, Linkedin, Mail, CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { PageHeading } from "@/components/portfolio/sections";
import { createMessageDraft, pageMeta, portfolio } from "@/data/portfolio";

export const Route = createFileRoute("/contact")({
  head: () =>
    pageMeta(
      "Contact",
      "Get in touch with MUSTELLO about Minecraft plugins, Bedrock addons, crossplay, or development opportunities. Prepare a project inquiry.",
    ),
  component: Contact,
});

function Contact() {
  const [status, setStatus] = useState("");
  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    const name = String(data.get("name") || "");
    const email = String(data.get("email") || "");
    const message = String(data.get("message") || "");
    if (portfolio.email) {
      window.location.href = `mailto:${portfolio.email}?subject=${encodeURIComponent(`Portfolio inquiry from ${name}`)}&body=${encodeURIComponent(`From: ${name} <${email}>\n\n${message}`)}`;
      setStatus("Your email app has been requested. Review and send your message there.");
      return;
    }
    const url = URL.createObjectURL(
      new Blob([createMessageDraft(name, email, message)], { type: "text/plain;charset=utf-8" }),
    );
    const link = document.createElement("a");
    link.href = url;
    link.download = "mustello-message-draft.txt";
    link.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    setStatus(
      "Your message draft is downloaded. Nothing has been sent; a contact email is still needed.",
    );
  }
  return (
    <main id="main">
      <PageHeading
        kicker="Start a conversation"
        title="Let’s build something great."
        description="A custom plugin, a new gameplay idea, or a development opportunity — it starts with a conversation."
      />
      <section className="page-wrap section grid gap-12 md:grid-cols-[.8fr_1.2fr]">
        <div>
          <h2 className="section-title">Get in touch.</h2>
          <p className="section-copy mt-4">
            Share what you have in mind, the edition you’re building for, and the details that
            matter to your project.
          </p>
          <div className="mt-8 space-y-6">
            {[
              {
                icon: Mail,
                title: "Email",
                url: portfolio.email ? `mailto:${portfolio.email}` : "",
                label: portfolio.email,
              },
              {
                icon: Github,
                title: "GitHub",
                url: portfolio.github,
                label: "View GitHub profile",
              },
              {
                icon: Linkedin,
                title: "LinkedIn",
                url: portfolio.linkedin,
                label: "View LinkedIn profile",
              },
            ].map(({ icon: Icon, title, url, label }) => (
              <div key={title} className="flex items-center gap-4">
                <span className="icon-tile">
                  <Icon size={19} />
                </span>
                <div>
                  <h3 className="text-sm font-semibold">{title}</h3>
                  {url ? (
                    <a
                      href={url}
                      className="text-xs text-primary"
                      target={title === "Email" ? undefined : "_blank"}
                      rel="noreferrer"
                    >
                      {label} ↗
                    </a>
                  ) : (
                    <p className="mt-1 text-xs text-muted-foreground">Not provided yet</p>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
        <form onSubmit={submit} className="space-y-5">
          <h2 className="text-xl font-semibold">Tell me about your idea.</h2>
          <div className="grid gap-5 sm:grid-cols-2">
            <label className="block text-xs font-medium">
              Your name
              <input
                className="form-field mt-2"
                name="name"
                required
                maxLength={100}
                autoComplete="name"
                placeholder="Your name"
              />
            </label>
            <label className="block text-xs font-medium">
              Your email
              <input
                className="form-field mt-2"
                name="email"
                type="email"
                required
                maxLength={254}
                autoComplete="email"
                placeholder="you@example.com"
              />
            </label>
          </div>
          <label className="block text-xs font-medium">
            Your message
            <textarea
              className="form-field mt-2 min-h-40 resize-y"
              name="message"
              required
              maxLength={10000}
              placeholder="What are you looking to build?"
            />
          </label>
          <p className="text-xs leading-relaxed text-muted-foreground">
            {portfolio.email
              ? "Continue in your email app to send your inquiry."
              : "Contact email not yet provided. Save your inquiry as a message draft; it will not be sent."}
          </p>
          <Button type="submit" size="lg">
            {portfolio.email ? (
              <>
                Open email <ArrowUpRight />
              </>
            ) : (
              <>
                Download message draft <Download />
              </>
            )}
          </Button>
          {status && (
            <p
              role="status"
              className="flex items-start gap-2 text-xs leading-relaxed text-muted-foreground"
            >
              <CheckCircle2 size={16} className="shrink-0 text-success" />
              {status}
            </p>
          )}
        </form>
      </section>
    </main>
  );
}
