import { createFileRoute } from "@tanstack/react-router";
import { ExperienceSection, ContactBanner, PageHeading } from "@/components/portfolio/sections";
import { pageMeta } from "@/data/portfolio";
export const Route = createFileRoute("/experience")({
  head: () =>
    pageMeta(
      "Experience",
      "MUSTELLO’s experience and milestones. Genuine roles, education, contributions, and achievements will be added when provided.",
    ),
  component: Experience,
});
function Experience() {
  return (
    <main id="main">
      <PageHeading
        kicker="Learning. Building. Improving."
        title="The story behind the work."
        description="Real experience matters. This timeline is reserved for genuine projects, contributions, and milestones."
      />
      <ExperienceSection />
      <ContactBanner />
    </main>
  );
}
