import { createFileRoute } from "@tanstack/react-router";
import {
  AboutSection,
  ContactBanner,
  Hero,
  ProjectsSection,
  SkillsSection,
  TechStrip,
} from "@/components/portfolio/sections";
import { pageMeta } from "@/data/portfolio";

// The home route ships no og:image, so serve-time hosting can inject the
// project's social preview (explicit og:image or latest screenshot).
export const Route = createFileRoute("/")({
  component: Index,
  head: () =>
    pageMeta(
      "Minecraft Developer & Creative Builder",
      "MUSTELLO creates custom Minecraft plugins, Bedrock addons, smarter mobs, and seamless crossplay experiences.",
    ),
});

// IMPORTANT: Replace this placeholder. See ./README.md for routing conventions.
function Index() {
  return (
    <main id="main">
      <Hero />
      <TechStrip />
      <AboutSection compact />
      <SkillsSection compact />
      <ProjectsSection compact />
      <ContactBanner />
    </main>
  );
}
