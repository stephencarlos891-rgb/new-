import { createFileRoute } from "@tanstack/react-router";
import { ProjectsSection, ContactBanner, PageHeading } from "@/components/portfolio/sections";
import { pageMeta } from "@/data/portfolio";

export const Route = createFileRoute("/projects")({
  head: () =>
    pageMeta(
      "Projects",
      "Explore MUSTELLO’s illustrative sample concepts for Java plugins, Bedrock addons, custom mobs, crossplay, and Minecraft server development.",
    ),
  component: Projects,
});

function Projects() {
  return (
    <main id="main">
      <PageHeading
        kicker="The project collection"
        title="Code that becomes an experience."
        description="Plugins, addons, connected worlds, and systems concepts. Every image and project card here is an illustrative sample concept, not completed client work."
      />
      <ProjectsSection />
      <ContactBanner />
    </main>
  );
}
