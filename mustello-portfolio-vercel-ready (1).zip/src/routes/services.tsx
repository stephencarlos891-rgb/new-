import { createFileRoute } from "@tanstack/react-router";
import { ServicesSection, ContactBanner, PageHeading } from "@/components/portfolio/sections";
import { pageMeta } from "@/data/portfolio";
export const Route = createFileRoute("/services")({
  head: () =>
    pageMeta(
      "Development Services",
      "Minecraft plugin development, Bedrock addons, crossplay configuration, server optimization, and advanced debugging by MUSTELLO.",
    ),
  component: Services,
});
function Services() {
  return (
    <main id="main">
      <PageHeading
        kicker="Made for your Minecraft"
        title="Bring your next idea to life."
        description="Custom development focused on the mechanics, content, and connections your server needs."
      />
      <ServicesSection />
      <ContactBanner />
    </main>
  );
}
