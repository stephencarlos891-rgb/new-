import { createFileRoute } from "@tanstack/react-router";
import { SkillsSection, ContactBanner, PageHeading } from "@/components/portfolio/sections";
import { pageMeta } from "@/data/portfolio";
export const Route = createFileRoute("/skills")({
  head: () =>
    pageMeta(
      "Technical Skills",
      "Explore MUSTELLO’s Minecraft technical focus: Java, JavaScript, Paper, Spigot, Bedrock scripting, GeyserMC, and optimization.",
    ),
  component: Skills,
});
function Skills() {
  return (
    <main id="main">
      <PageHeading
        kicker="Tools of the trade"
        title="The right tools for your world."
        description="From server-side logic to custom entities, a toolkit built around thoughtful Minecraft development."
      />
      <SkillsSection />
      <ContactBanner />
    </main>
  );
}
