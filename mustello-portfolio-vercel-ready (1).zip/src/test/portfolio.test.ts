import { describe, expect, it } from "vitest";
import {
  categories,
  createMessageDraft,
  filterProjects,
  portfolio,
  projects,
} from "@/data/portfolio";

describe("Portfolio content rules", () => {
  it("contains five clearly editable sample-concept projects", () => {
    expect(projects.map((project) => project.id)).toEqual([
      "java",
      "bedrock",
      "mobs",
      "crossplay",
      "server",
    ]);
    expect(projects).toHaveLength(5);
    expect(new Set(projects.map((project) => project.image)).size).toBe(5);
    expect(
      projects.every((project) => project.sourceUrl.startsWith("https://commons.wikimedia.org/")),
    ).toBe(true);
  });
  it("does not invent social profiles or project links", () => {
    expect([portfolio.email, portfolio.github, portfolio.linkedin]).toEqual(["", "", ""]);
    expect(projects.every((project) => project.github === "" && project.demo === "")).toBe(true);
  });
  it.each(categories.slice(1))("filters %s without leaking other categories", (category) => {
    expect(filterProjects(category).map((project) => project.category)).toEqual([category]);
  });
  it("returns all five projects for the all-projects filter", () => {
    expect(filterProjects("All projects").map((project) => project.id)).toEqual([
      "java",
      "bedrock",
      "mobs",
      "crossplay",
      "server",
    ]);
  });
  it("creates a message draft with real input and no invented recipient", () => {
    const draft = createMessageDraft("Alex", "alex@example.com", "A Paper plugin for my server");
    expect(draft).toContain("To: [MUSTELLO’s email — not yet provided]");
    expect(draft).toContain("From: Alex <alex@example.com>");
    expect(draft).toContain("A Paper plugin for my server");
  });
});
